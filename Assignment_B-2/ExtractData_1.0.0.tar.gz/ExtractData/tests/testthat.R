library(testthat)
library(ExtractData)

test_check("ExtractData")
