test_that("Check ouput class of the RegionSell function.", {
  testthat::expect_true(is.data.frame(input_data))
})
