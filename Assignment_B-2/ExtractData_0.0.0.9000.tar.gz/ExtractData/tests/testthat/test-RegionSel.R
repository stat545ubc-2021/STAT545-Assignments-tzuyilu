test_that("Check ouput class of the RegionSell function.", {
  expect_true(is.data.frame(VanTreeUBC))
})
